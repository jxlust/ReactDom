import React from 'react';

class Home extends React.Component {
	constructor(props) {
		super(props)
	}
	render() {
		return (<div>首页哈哈哈哈</div>)
	}
}
export default Home;