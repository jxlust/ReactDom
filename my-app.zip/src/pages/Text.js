import React from 'react';

class Home extends React.Component {
	constructor(props) {
		super(props)
	}
	render() {
		return (<div>我是文本哈哈哈哈</div>)
	}
}
export default Home;