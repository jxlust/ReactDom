import * as React from 'react';
import * as ReactDOM from 'react-dom';
import Dialog from './dialog.js';
const staticize  = (props) => {
	return new Promise((resolve) => {
			const wrap = document.createElement('div');
			document.body.appendChild(wrap);
			const close = () => {
				document.body.removeChild(wrap);
			}
			const sure = () => {
				close();
				resolve();
			}
			ReactDOM.render(<Dialog {...props} onCancel={close} onConfirm={sure} />,wrap);
	})
}

export default staticize;