import styles from './dialog.scss'
import * as React from 'react'
// import cx from 'classnames'
function FancyBorder (props) {
	return <div className="FancyMask">
		<div className={`FancyWrap FancyBorder FancyBorder-${props.color}`}>
			{props.children}
		</div>
	</div>

}

function WelcomeDialog ({
	title,
	message,
	onConfirm,
	onCancel,
}) {
	return <FancyBorder color="blue">
		<h1 className="Dialog-title">
			{title}
		</h1>
		<p className="Dialog-message">
			{message}
		</p>

		<div className={styles.btngroup}>
			<button className={styles.button} onClick={onCancel}>取消</button>
			<button className={`${styles.button} ${styles.active}`} onClick={onConfirm}>确定</button>
		</div>
	</FancyBorder>
}

export default WelcomeDialog;