import * as React from 'react';
// import styles from './question.scss';
import  './question.scss';
function FormItem(props) {
		return <div>{props.label}</div>
}

class Question extends React.Component {
	constructor(props) {
		super(props)
		this.state = {
			results:[]
		}
	}

	render() {
		const lists = this.props.questions;
		// item:
		// type: 'Single',
		// label: '你最喜欢的水果？',
		// require: true,
		// options:
		console.log(111,lists);
		return (<div className="q-form">
			{lists.map(item => <FormItem {...item}></FormItem>)}
		</div>)
	}
}

export default Question;
