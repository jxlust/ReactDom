import * as React from 'react';
import styles from './question.scss';
function FormItem(props) {
	
}

class Question extends React.Component {
	constructor(props) {
		super(props)
	}

	render() {
		return (<div></div>)
	}
}
