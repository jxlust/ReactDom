const data = {
	id: 1,
	title: '我是xxxxx问卷调查',
	describe: 'xxxxxx描述，萨迦县冷静下来结束啦，xxxxxxxx',
	questions: [{
		type: 'Single',
		label: '你最喜欢的水果？',
		require: true,
		options: [{
			label: '香蕉',
			value: 'banana'
		}, {
			label: '橘子',
			value: 'orange'
		}, {
			label: '苹果',
			value: 'apple'
		}]
	}, {
		type: 'Multiple',
		label: '你最喜欢的书籍？',
		require: true,
		options: [{
			label: 'book1',
			value: 'b1'
		}, {
			label: 'book2',
			value: 'b2'
		}, {
			label: 'book3',
			value: 'b3'
		}, {
			label: 'book4',
			value: 'b4'
		}]
	}, {
		type: 'Text',
		label: '你最喜欢的书籍？',
		require: true,
		options: null,
	}, {
		type: 'Single',
		label: '你最喜欢的东东？',
		require: true,
		options: [{
			label: '香蕉',
			value: 'banana'
		}, {
			label: '橘子',
			value: 'orange'
		}, {
			label: '苹果',
			value: 'apple'
		}, {
			label: '其他',
			value: 'other'
		}]
	}],
}

export default data;