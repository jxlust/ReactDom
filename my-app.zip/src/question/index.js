import Question from './question.jsx';
import * as React from 'react';
import data from './data';
class QPage extends React.Component{
	constructor(props){
		super(props)
	}
	render(){
		return <Question questions={data.questions}></Question>
	}
}

export default QPage;