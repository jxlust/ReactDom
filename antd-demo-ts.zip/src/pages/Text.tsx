import * as React from 'react';
import '@/styles/user.scss';
export default class User extends React.Component<any, any> {

    render() {
        // let { match } = this.props
        // const name = match.params.name
				let {name} = this.props;
        return <div className="user-wrap">
            <h2>user用户页面</h2>
						<div className="name"> 这是用户 {name}</div>
           
        </div>
    }
}